-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Jul 2020 pada 09.33
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tiketonline`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kereta`
--

CREATE TABLE `kereta` (
  `id_kereta` int(10) NOT NULL,
  `nama_kereta` varchar(20) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `sub_kelas` varchar(20) NOT NULL,
  `dari` varchar(20) NOT NULL,
  `tujuan` varchar(20) NOT NULL,
  `jumlah_kursi` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kereta`
--

INSERT INTO `kereta` (`id_kereta`, `nama_kereta`, `kelas`, `sub_kelas`, `dari`, `tujuan`, `jumlah_kursi`) VALUES
(77, 'TURANGGA', 'EKSEKUTIF', 'AA,J,H,I,A', 'SURABAYA GUBENG', 'GAMBIR', 200),
(78, 'TURANGGA', 'EKSEKUTIF', 'AA,J,H,I,A', 'GAMBIR', 'SURABAYA GUBENG', 200);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan`
--

CREATE TABLE `pemesanan` (
  `id_pemesanan` int(16) NOT NULL,
  `nama_pemesanan` varchar(30) NOT NULL,
  `alamat_pemesan` varchar(30) NOT NULL,
  `telepon_pemesan` varchar(16) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pemesanan`
--

INSERT INTO `pemesanan` (`id_pemesanan`, `nama_pemesanan`, `alamat_pemesan`, `telepon_pemesan`, `email`) VALUES
(1741160008, 'RETNA KUSUMA', 'MALANG', '085608508630', 'retnaarka@gmail.com'),
(1741160066, 'MOHAMMAD ADIB', 'MALANG', '081245255195', 'adib.palu@gamail.com '),
(1741160068, 'FEBIOLA KIREYNA', 'MADIUN', '082334293121', 'febiolakireyna12@gmail.com'),
(1741160100, 'CLARINTA SHANKENDRA', 'MALANG', '082233807694', 'clarintashankendra@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tiket`
--

CREATE TABLE `tiket` (
  `id_tiket` varchar(16) NOT NULL,
  `id_kereta` int(10) NOT NULL,
  `id_pemesan` int(16) NOT NULL,
  `no_kursi` varchar(10) NOT NULL,
  `jadwal` date NOT NULL,
  `kelas` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tiket`
--

INSERT INTO `tiket` (`id_tiket`, `id_kereta`, `id_pemesan`, `no_kursi`, `jadwal`, `kelas`) VALUES
('5P53YIZ', 77, 1741160100, '6B', '2020-07-08', 'EKSEKUTIF'),
('DT63LDO', 77, 1741160008, '6A', '2020-07-08', 'EKSEKUTIF'),
('MC939X8', 78, 1741160068, '6C', '2020-07-08', 'EKSEKUTIF'),
('YDI33JO', 78, 1741160066, '6D', '2020-07-08', 'EKSEKUTIF');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kereta`
--
ALTER TABLE `kereta`
  ADD PRIMARY KEY (`id_kereta`);

--
-- Indeks untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id_pemesanan`);

--
-- Indeks untuk tabel `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id_tiket`),
  ADD KEY `id_pemesan` (`id_pemesan`),
  ADD KEY `id_kereta` (`id_kereta`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id_pemesanan` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1741160101;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tiket`
--
ALTER TABLE `tiket`
  ADD CONSTRAINT `tiket_ibfk_1` FOREIGN KEY (`id_pemesan`) REFERENCES `pemesanan` (`id_pemesanan`),
  ADD CONSTRAINT `tiket_ibfk_2` FOREIGN KEY (`id_kereta`) REFERENCES `kereta` (`id_kereta`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
